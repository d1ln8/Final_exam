const container = document.getElementById('articles-container');
const mostPopular = document.getElementById('most-popular');
const themeToggle = document.getElementById('themeToggle');
const sortSelect = document.getElementById('sortSelect');
let allArticles = [];

// Загрузка JSON
fetch('articles.json')
  .then(res => res.json())
  .then(data => {
    allArticles = data;
    renderArticles(data);
    updateMostPopular(data);
  });

// Отображение всех новостей
function renderArticles(articles) {
  container.innerHTML = '';
  articles.forEach(article => {
    const time = Math.ceil(article.wordCount / 200);
    const card = `
      <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
          <img src="${article.image}" class="card-img-top" alt="${article.title}">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title">${article.title}</h5>
            <p class="card-text"><strong>${article.category}</strong> | ${article.date}</p>
            <p class="card-text">${article.content.slice(0, 100)}...</p>
            <p class="text-muted">👁️ ${article.views} | 🕒 ${time} min read</p>
            <button class="btn btn-outline-primary mt-auto" onclick="openArticle('${article.title}', \`${article.content}\`)">Read completely</button>
          </div>
        </div>
      </div>`;
    container.insertAdjacentHTML('beforeend', card);
  });
}

// Вывод самой популярной статьи
function updateMostPopular(articles) {
  const top = articles.reduce((prev, curr) => curr.views > prev.views ? curr : prev, articles[0]);
  const time = Math.ceil(top.wordCount / 200);

  mostPopular.innerHTML = `
    <div class="highlight-card p-3 shadow-sm">
      <img src="${top.image}" class="img-fluid rounded mb-3" alt="${top.title}">
      <h5 class="fw-bold">${top.title}</h5>
      <p class="text-muted">${top.date} | <strong>${top.category}</strong></p>
      <p>${top.content}</p>
      <p class="text-muted">👁️ ${top.views} | 🕒 ${time} min read</p>
      <button class="btn btn-primary" onclick="openArticle('${top.title}', \`${top.content}\`)">Read completely</button>
    </div>
  `;
}

// ✅ Применяем сохранённую тему при загрузке
window.onload = () => {
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.body.classList.toggle('dark-mode');
document.body.classList.toggle('light-mode');
  themeToggle.textContent = savedTheme === 'dark' ? 'Light Mode' : 'Dark Mode';
};

// ✅ Переключение темы по кнопке
themeToggle.addEventListener('click', () => {
  const isDark = document.body.classList.contains('dark-mode');
  document.body.classList.remove('light-mode', 'dark-mode');
  const newTheme = isDark ? 'light' : 'dark';
  document.body.classList.add(`${newTheme}-mode`);
  localStorage.setItem('theme', newTheme);
  themeToggle.textContent = newTheme === 'dark' ? 'Light Mode' : 'Dark Mode';
});

// Сортировка по дате или просмотрам
sortSelect.addEventListener('change', () => {
  const sorted = [...allArticles];
  if (sortSelect.value === 'date') {
    sorted.sort((a, b) => new Date(b.date) - new Date(a.date));
  } else {
    sorted.sort((a, b) => b.views - a.views);
  }
  renderArticles(sorted);
  updateMostPopular(sorted);
});

// Фильтрация по категориям
document.addEventListener('click', e => {
  if (e.target.classList.contains('category-link')) {
    e.preventDefault();
    const category = e.target.dataset.category;
    const filtered = category === 'All' ? allArticles : allArticles.filter(a => a.category === category);
    renderArticles(filtered);
    updateMostPopular(filtered);
  }
});

// Открытие статьи
function openArticle(title, content) {
  alert(`${title}\n\n${content}`);
}
